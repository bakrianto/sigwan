<?php
error_reporting(0);
$conn = mysqli_connect('localhost','puskeswan','andromax4glte');
mysqli_select_db($conn,'puskeswa_puskeswan');
?>